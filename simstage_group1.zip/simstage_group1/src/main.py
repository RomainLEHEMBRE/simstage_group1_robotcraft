#!/usr/bin/env python3

import rospy  # Main ROS library for Python (for creating a node, subscribers, etc.)
import numpy as np  
from std_msgs.msg import String  
from geometry_msgs.msg import Twist  # Allows publishing velocity commands
from sensor_msgs.msg import LaserScan  # Message type for LiDAR data
import random


# Define a ROS class containing the node
class TalkerClass:
    def __init__(self):
        # ROS node initialization
        rospy.init_node("talker_node", anonymous=True)
        
        # Create a publisher on the "cmd_vel" topic to send velocity commands
        self.publisher_0 = rospy.Publisher("/cmd_vel", Twist, queue_size=10)
        # Subscribe to the "scan" topic to receive LiDAR data
        self.subscriber_0 = rospy.Subscriber("/base_scan", LaserScan, self.callback)
        # Define the publishing frequency (10 Hz)
        self.rate = rospy.Rate(10)
        # Keep the node active and listening for messages
        rospy.spin()

    # Function called every time LiDAR data is received
    def callback(self, scan_data):
        # Convert LiDAR ranges into a NumPy array
        # 0 is close to a wall, 1 is far from a wall
        
        ranges = np.array(scan_data.ranges)
        # Filter for valid values: greater than 0.0 and not NaN
        ranges = ranges[(~np.isnan(ranges)) & (ranges > 0.0)]
        # Prepare the velocity message
        msg = Twist()

        threshold = 1  # Minimum distance to consider an obstacle
        front_angle = 50 # Frontal angle 
        side_angle = 40 # Frontal angle 
        total_samples = len(scan_data.ranges) # Total number of measurements in the scan
        # the values of the lidar are between 0 and 5.6

        mid_index = total_samples // 2 # The middle tabl index
        quarter_index = total_samples // 4 # for the sides
        
        front_width = int((front_angle / 240.0) * total_samples) # Returns the number of points in 50 degrees
        side_width = int((side_angle / 240.0) * total_samples)
        
        # Save the 50 degrees point value in the first tab
        front_ranges = scan_data.ranges[mid_index - int(front_width/2) : mid_index + int(front_width/2)]
         # Save the 40 degrees point value in the first tab (left side)
        right_side_ranges = scan_data.ranges[mid_index + front_width : mid_index + front_width + side_width] #(240*90)/360
         # Save the 40 degrees point value in the first tab (right)
        left_side_ranges = scan_data.ranges[mid_index -front_width - side_width : mid_index -front_width]

        # Filter valid ranges in this sector
        valid_front_ranges = [r for r in front_ranges if not np.isnan(r) and r > 0.0]
        valid_left_side_ranges = [r for r in left_side_ranges if not np.isnan(r) and r > 0.0]
        valid_right_side_ranges = [r for r in right_side_ranges if not np.isnan(r) and r > 0.0]
        
        
        # Robot orientation conditions
        if  valid_front_ranges and min(valid_front_ranges) < threshold :
            
            avg_left = np.mean(valid_left_side_ranges) if valid_left_side_ranges else 0.0 # calculate the average of the left side datas
            avg_right = np.mean(valid_right_side_ranges) if valid_right_side_ranges else 0.0 # calculate the average of the right side datas
            
            turn_speed = max(0.6, (threshold - min(valid_front_ranges)) * 1.0) # minimum velocity = 0.6
            
            if avg_left<avg_right: #if the left space is smaller than the right space
                msg.linear.x = 0.1 * min(valid_left_side_ranges)       
                msg.angular.z = turn_speed + random.uniform(-0.3, 0.3)
            
            else:
                msg.linear.x = 0.1 * min(valid_right_side_ranges)       #
                msg.angular.z = -turn_speed + random.uniform(-0.3, 0.3)
            
        else:    
            msg.linear.x=1
            msg.angular.z = random.uniform(-0.2, 0.2)
            
        # Send the velocity command to the robot
        self.publisher_0.publish(msg)


# Main function: launches the class
if __name__ == '__main__':
    try:
        talker = TalkerClass()
             
    except rospy.ROSInterruptException:
        pass